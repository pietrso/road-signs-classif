# -*- coding: utf-8 -*-
"""
Load the dataset of Sign detection

    from sign_detection import load_data
    (x_train, y_train), (x_valid, y_valid), (x_test, y_test) = load_data()

@author: Davide
"""
import os
from skimage import io
import numpy as np
import glob
import tqdm

def check_ext(filename):
    for ext in ['.jpg','.jpeg','.png','.JPG','.JPEG','.PNG']:
        if filename.endswith(ext): 
            return True
    return False

def load_data():
    """
    Load the dataset of Sign detection

    (x_train, y_train), (x_valid, y_valid), (x_test, y_test) = load_data()

    """
    root_data = os.path.dirname(__file__)
    list_sets = ['train','valid','test']
    
    list_class = list()
    for name_set in list_sets:
        list_class = list_class+[_ for _ in os.listdir(root_data+'/'+name_set)
                                 if (not _.startswith('.')) and os.path.isdir(root_data+'/'+name_set+'/'+_)]
    list_class = sorted(list(set(list_class)))
    
    output_t = list()
    for name_set in list_sets:
        list_image = list()
        list_label = list()
        for index_class, name_class in enumerate(list_class):
            path_class = root_data+'/'+name_set+'/'+name_class
            list_img = [_ for _ in os.listdir(path_class)
                        if check_ext(_) and os.path.isfile(path_class+'/'+_)]
            for name_img in tqdm.tqdm(list_img, desc="%s %d"%(name_set, index_class)):
                list_image.append(io.imread(path_class+'/'+name_img))
                list_label.append(index_class)
        output_t.append((np.stack(list_image,0),np.stack(list_label,0)))
    return tuple(output_t)